package com.ufrn.loja.Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.ufrn.lojaonline.dao.ProdutoDAO;
import br.ufrn.lojaonline.model.Carrinho;
import br.ufrn.lojaonline.model.ItemCarrinho;

@WebServlet("/finalizar")
public class FinalizaCompraController extends HttpServlet {

    private final ProdutoDAO produtoDao;

    public FinalizaCompraController() throws SQLException {
        this.produtoDao = new ProdutoDAO();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if(session == null || session.getAttribute("carrinho") == null) {
            resp.sendRedirect("/produtos");
            return;
        }

        Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");

        try {
            // Atualiza estoque
            for(ItemCarrinho item : carrinho.getItens()) {
                produtoDao.atualizarEstoque(item.getProduto().getId(), item.getQuantidade());
            }

            // Limpa carrinho
            session.removeAttribute("carrinho");

            resp.sendRedirect("/produtos?compra=success");
        } catch (SQLException e) {
            resp.sendRedirect("/carrinho?erro=1");
        }
    }
}
