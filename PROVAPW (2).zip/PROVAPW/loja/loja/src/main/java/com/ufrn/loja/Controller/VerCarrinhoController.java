package com.ufrn.loja.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.ufrn.lojaonline.model.Carrinho;
import br.ufrn.lojaonline.model.ItemCarrinho;

@WebServlet("/carrinho")
public class VerCarrinhoController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("carrinho") == null) {
            resp.sendRedirect("/produtos");
            return;
        }

        Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Carrinho</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; margin: 20px; }");
        out.println(".item { border: 1px solid #ddd; padding: 10px; margin: 10px 0; }");
        out.println(".total { font-weight: bold; margin-top: 20px; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Seu Carrinho</h1>");

        if (carrinho.getItens().isEmpty()) {
            out.println("<p>Carrinho vazio</p>");
        } else {
            for (ItemCarrinho item : carrinho.getItens()) {
                out.println("<div class='item'>");
                out.println("<h3>" + item.getProduto().getNome() + "</h3>");
                out.println("<p>Preço unitário: R$ " + String.format("%.2f", item.getProduto().getPreco()) + "</p>");
                out.println("<p>Quantidade: " + item.getQuantidade() + "</p>");
                out.println("<a href='/carrinho/remover?id=" + item.getProduto().getId() + "'>Remover</a>");
                out.println("</div>");
            }

            out.println("<div class='total'>");
            out.println("Total: R$ " + String.format("%.2f", carrinho.getTotal()));
            out.println("</div>");
            out.println("<a href='/finalizar'>Finalizar Compra</a>");
        }

        out.println("<a href='/produtos'>Continuar Comprando</a>");
        out.println("</body>");
        out.println("</html>");
    }
}
