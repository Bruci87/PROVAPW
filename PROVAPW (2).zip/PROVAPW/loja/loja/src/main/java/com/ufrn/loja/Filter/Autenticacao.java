package com.ufrn.loja.Filter;


public class Autenticacao {

    // Método para autenticar um lojista
    public static boolean autenticarLojista(Lojista lojista, String email, String senha) {
        return lojista.getEmail().equals(email) && lojista.getSenha().equals(senha);
    }

    // Método para autenticar um cliente
    public static boolean autenticarCliente(Cliente cliente, String email, String senha) {
        return cliente.getEmail().equals(email) && cliente.getSenha().equals(senha);
    }

    // Método de exemplo que poderia ser mais geral se necessário
    public static boolean autenticar(String email, String senha, Object usuario) {
        if (usuario instanceof Lojista) {
            Lojista lojista = (Lojista) usuario;
            return autenticarLojista(lojista, email, senha);
        } else if (usuario instanceof Cliente) {
            Cliente cliente = (Cliente) usuario;
            return autenticarCliente(cliente, email, senha);
        }
        return false;
    }

}
