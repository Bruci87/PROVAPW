package com.ufrn.loja.Controller;

import br.ufrn.lojaonline.model.Carrinho;
import br.ufrn.lojaonline.model.ItemCarrinho;
import br.ufrn.lojaonline.model.Produto;
import br.ufrn.lojaonline.dao.ProdutoDAO;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;

public class LojaServlet extends HttpServlet {

    // Servlet para Login
    public static class LoginServlet extends HttpServlet {
        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
            String email = req.getParameter("email");
            String senha = req.getParameter("senha");

            if ("admin@loja.com".equals(email) && "123".equals(senha)) {
                req.getSession().setAttribute("usuario", email);
                resp.sendRedirect("lista-produtos");
            } else {
                resp.setContentType("text/html");
                resp.getWriter().println("<h2>Login falhou. Tente novamente.</h2>");
            }
        }
    }

    // Servlet para Cadastro de Produto (exemplo simplificado)
    public static class CadastroProdutoServlet extends HttpServlet {
        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
            String nome = req.getParameter("nome");
            double preco = Double.parseDouble(req.getParameter("preco"));

            Produto produto = new Produto();
            produto.setNome(nome);
            produto.setPreco(preco);

            ProdutoDAO dao = new ProdutoDAO();
            dao.inserir(produto);

            resp.setContentType("text/html");
            resp.getWriter().println("<h2>Produto cadastrado com sucesso!</h2>");
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            ProdutoDAO dao = new ProdutoDAO();
            @Override
            protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
                for (Produto p : dao.listarTodos()) {

                    resp.setContentType("text/html");
                    resp.getWriter().println("<h1>Produtos disponíveis:</h1><ul>");
                    for (Produto p : dao.listarTodos()) {
                        resp.getWriter().println("<li>" + p.getNome() + " - R$ " + p.getPreco() +
                                " <form action='adicionar-ao-carrinho' method='post' style='display:inline;'>" +
                                "<input type='hidden' name='produtoId' value='" + p.getId() + "'/>" +
                                "<input type='number' name='quantidade' value='1' min='1'/>" +
                                "<input type='submit' value='Adicionar ao Carrinho'/>" +
                                "</form></li>");
                    }
                    resp.getWriter().println("</ul>");
                }
            }

            // Servlet para Adicionar Produto ao Carrinho
            public static class AdicionarAoCarrinhoServlet extends HttpServlet {
                @Override
                protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                    int produtoId = Integer.parseInt(req.getParameter("produtoId"));
                    int quantidade = Integer.parseInt(req.getParameter("quantidade"));

                    ProdutoDAO dao = new ProdutoDAO();
                    Produto produto = dao.buscarPorId(produtoId);

                    if (produto == null) {
                        resp.getWriter().println("<h2>Produto não encontrado.</h2>");
                        return;
                    }

                    HttpSession sessao = req.getSession();
                    Carrinho carrinho = (Carrinho) sessao.getAttribute("carrinho");

                    if (carrinho == null) {
                        carrinho = new Carrinho();
                        sessao.setAttribute("carrinho", carrinho);
                    }

                    carrinho.adicionarItem(produto, quantidade);

                    resp.setContentType("text/html");
                    resp.getWriter().println("<h2>" + produto.getNome() + " adicionado ao carrinho.</h2>");
                    resp.getWriter().println("<a href='lista-produtos'>Voltar</a>");
                }
            }

            // Servlet para Finalizar Compra
            public static class FinalizarCompraServlet extends HttpServlet {
                @Override
                protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
                    HttpSession sessao = req.getSession();
                    Carrinho carrinho = (Carrinho) sessao.getAttribute("carrinho");

                    resp.setContentType("text/html");
                    if (carrinho == null || carrinho.isEmpty()) {
                        resp.getWriter().println("<h2>Seu carrinho está vazio.</h2>");
                    } else {
                        resp.getWriter().println("<h2>Compra finalizada com os seguintes produtos:</h2><ul>");
                        for (ItemCarrinho item : carrinho.getItens()) {
                            Produto p = item.getProduto();
                            resp.getWriter().println("<li>" + p.getNome() + " - Quantidade: " + item.getQuantidade() +
                                    " - Preço unitário: R$ " + p.getPreco() + "</li>");
                        }
                        resp.getWriter().println("</ul>");
                        resp.getWriter().println("<strong>Total: R$ " + carrinho.getTotal() + "</strong>");
                        sessao.removeAttribute("carrinho");
                    }
                }
            }

            // Servlet para Logout
            public static class LogoutServlet extends HttpServlet {
                @Override
                protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
                    req.getSession().invalidate();
                    resp.setContentType("text/html");
                    resp.getWriter().println("<h2>Logout realizado com sucesso.</h2>");
                    resp.getWriter().println("<a href='login.html'>Voltar para login</a>");
                }
            }
        }
