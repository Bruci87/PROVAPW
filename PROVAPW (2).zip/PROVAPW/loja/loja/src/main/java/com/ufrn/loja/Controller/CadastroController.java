package com.ufrn.loja.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ufrn.lojaonline.dao.ClienteDAO;
import br.ufrn.lojaonline.model.Cliente;

@WebServlet("/cadastro")
public class CadastroController extends HttpServlet {

    private final ClienteDAO clienteDao;

    public CadastroController() {
        try {
            this.clienteDao = new ClienteDAO();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize ClienteDAO", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Cadastro</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; margin: 20px; }");
        out.println("form { max-width: 300px; margin: 0 auto; }");
        out.println("input { margin-bottom: 10px; width: 100%; padding: 8px; }");
        out.println(".error { color: red; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Cadastro de Cliente</h2>");

        String erro = req.getParameter("erro");
        if(erro != null) {
            out.println("<p class='error'>" + erro + "</p>");
        }

        out.println("<form method='post'>");
        out.println("<input type='text' name='nome' placeholder='Nome' required><br>");
        out.println("<input type='email' name='email' placeholder='Email' required><br>");
        out.println("<input type='password' name='senha' placeholder='Senha' required><br>");
        out.println("<button type='submit'>Cadastrar</button>");
        out.println("</form>");
        out.println("<p>Já tem conta? <a href='/login'>Faça login</a></p>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nome = req.getParameter("nome");
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");

        try {
            if(clienteDao.existeEmail(email)) {
                resp.sendRedirect("/cadastro?erro=Email já cadastrado");
                return;
            }

            Cliente novo = new Cliente(0, nome, email, senha);
            clienteDao.cadastrar(novo);
            resp.sendRedirect("/login?cadastro=success");
        } catch (SQLException e) {
            resp.sendRedirect("/cadastro?erro=Erro no servidor");
        }
    }
}
