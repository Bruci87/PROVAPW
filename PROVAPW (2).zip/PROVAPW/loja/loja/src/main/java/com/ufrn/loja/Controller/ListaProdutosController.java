package com.ufrn.loja.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ufrn.lojaonline.dao.ProdutoDAO;
import br.ufrn.lojaonline.model.Produto;

@WebServlet("/produtos")
public class ListaProdutosController extends HttpServlet {

    private ProdutoDAO produtoDao;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            this.produtoDao = new ProdutoDAO();
        } catch (SQLException e) {
            throw new ServletException("Failed to initialize ProdutoDAO", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        try {
            StringBuilder html = new StringBuilder();
            html.append("<!DOCTYPE html>")
                    .append("<html>")
                    .append("<head>")
                    .append("<title>Produtos</title>")
                    .append("<style>")
                    .append("body { font-family: Arial; margin: 20px; }")
                    .append(".produto { border: 1px solid #ddd; padding: 10px; margin: 10px 0; }")
                    .append("</style>")
                    .append("</head>")
                    .append("<body>")
                    .append("<h1>Produtos Disponíveis</h1>");

            for (Produto p : produtoDao.listarTodos()) {
                html.append("<div class='produto'>")
                        .append("<h3>").append(p.getNome()).append("</h3>")
                        .append("<p>Preço: R$ ").append(String.format("%.2f", p.getPreco())).append("</p>")
                        .append("<p>Estoque: ").append(p.getEstoque()).append("</p>")
                        .append("<a href='/carrinho/adicionar?id=").append(p.getId()).append("'>Adicionar ao Carrinho</a>")
                        .append("</div>");
            }

            html.append("<a href='/carrinho'>Ver Carrinho</a>")
                    .append("</body>")
                    .append("</html>");

            out.println(html.toString());
        } catch (SQLException e) {
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public void destroy() {
        if (produtoDao != null) {
            produtoDao.close();  // Assegure-se de fechar a conexão com o banco de dados, se necessário
        }
    }
}
