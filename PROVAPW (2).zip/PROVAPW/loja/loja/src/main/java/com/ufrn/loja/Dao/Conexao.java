package com.ufrn.loja.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    // Configuração de conexão com o banco de dados
    private static final String URL = "jdbc:mysql://localhost:3306/loja_db";  // URL do banco de dados
    private static final String USUARIO = "root";  // Usuário do banco de dados
    private static final String SENHA = "Redstone87";  // Senha do banco de dados

    // Método para obter a conexão com o banco
    public static Connection getConnection() throws SQLException {
        try {
            // Estabelece a conexão com o banco de dados
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (SQLException e) {
            // Caso haja um erro, lançamos uma exceção personalizada
            throw new SQLException("Erro ao conectar com o banco de dados", e);
        }
    }
}
