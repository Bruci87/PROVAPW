package com.ufrn.loja.Dao;


import com.ufrn.loja.Dao.Conexao;
import java.sql.Connection;
import java.sql.SQLException;

public class TestaConexao {
    public static void main(String[] args) {
        try (Connection conn = Conexao.getConnection()) {
            System.out.println("✅ Conexão bem-sucedida com o banco de dados!");
        } catch (SQLException e) {
            System.err.println("❌ Falha na conexão:");
            e.printStackTrace();
        }
    }
}
