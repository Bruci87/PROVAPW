package com.ufrn.loja.Model;

import java.util.Objects;

public class Cliente extends Usuario {

    private String endereco;
    private String telefone;

    // Construtor padrão
    public Cliente(int par, String nome, String email, String senha) {
        super();
        this.setTipo("cliente");
    }

    // Construtor com atributos básicos
    public Cliente(String nome, String email, String senha) {
        super(nome, email, senha, "cliente");
    }

    // Construtor com todos os atributos
    public Cliente(int id, String nome, String email, String senha, String endereco, String telefone) {
        super(id, nome, email, senha, "cliente");
        this.endereco = endereco;
        this.telefone = telefone;
    }

    // Getters e Setters
    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    // Validação simples de dados (pode ser chamada antes de salvar)
    public boolean dadosValidos() {
        return getNome() != null && !getNome().trim().isEmpty()
                && getEmail() != null && getEmail().contains("@")
                && getSenha() != null && getSenha().length() >= 6;
    }

    // Método para verificar se é cliente (pode ser útil em controle de acesso)
    @Override
    public boolean isCliente() {
        return "cliente".equalsIgnoreCase(getTipo());
    }

    // toString para facilitar debug
    @Override
    public String toString() {
        return "Cliente{" +
                "id=" + getId() +
                ", nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", endereco='" + endereco + '\'' +
                ", telefone='" + telefone + '\'' +
                '}';
    }

    // equals e hashCode baseados no ID
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cliente)) return false;
        Cliente cliente = (Cliente) o;
        return getId() == cliente.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
