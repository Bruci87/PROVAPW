package com.ufrn.loja.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.ufrn.lojaonline.model.Lojista;
import br.ufrn.lojaonline.util.PersistenceUtil;

public class LojistaDAO {
    private final Connection conexao;

    public LojistaDAO() throws SQLException {
        this.conexao = PersistenceUtil.getConnection();
    }

    public Lojista buscarPorEmail(String email) throws SQLException {
        String sql = "SELECT * FROM lojistas WHERE email = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Lojista(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("email"),
                        rs.getString("senha")
                );
            }
        }
        return null;
    }

    public boolean validarCredenciais(String email, String senha) throws SQLException {
        String sql = "SELECT 1 FROM lojistas WHERE email = ? AND senha = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    public void close() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}