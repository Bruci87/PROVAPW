package com.ufrn.loja.Model;

import java.util.Objects;

public class Produto {

    private int id;
    private String nome;
    private double preco;
    private int estoque;
    private String descricao;
    private String categoria;

    // Construtor padrão
    public Produto() {}

    // Construtor com atributos essenciais
    public Produto(String nome, double preco, int estoque, String descricao, String categoria) {
        this.nome = nome;
        this.preco = preco;
        this.estoque = estoque;
        this.descricao = descricao;
        this.categoria = categoria;
    }

    // Construtor com todos os atributos (incluindo ID)
    public Produto(int id, String nome, double preco, int estoque, String descricao, String categoria) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.estoque = estoque;
        this.descricao = descricao;
        this.categoria = categoria;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Validação de produto
    public boolean produtoValido() {
        return nome != null && !nome.trim().isEmpty()
                && preco > 0
                && estoque >= 0
                && descricao != null && !descricao.trim().isEmpty()
                && categoria != null && !categoria.trim().isEmpty();
    }

    // Método para ajustar estoque quando um produto é comprado
    public void ajustarEstoque(int quantidade) {
        if (estoque >= quantidade) {
            estoque -= quantidade;
        } else {
            throw new IllegalArgumentException("Estoque insuficiente.");
        }
    }

    // Representação textual do Produto
    @Override
    public String toString() {
        return "Produto{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", preco=" + preco +
                ", estoque=" + estoque +
                ", descricao='" + descricao + '\'' +
                ", categoria='" + categoria + '\'' +
                '}';
    }

    // equals e hashCode baseados no ID
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Produto)) return false;
        Produto produto = (Produto) o;
        return id == produto.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
