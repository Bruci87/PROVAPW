package com.ufrn.loja.Model;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    private final List<ItemCarrinho> itens;

    public Carrinho() {
        this.itens = new ArrayList<>();
    }

    public void adicionarItem(Produto produto, int quantidade) {
        for (ItemCarrinho item : itens) {
            if (item.getProduto().getId() == produto.getId()) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                return;
            }
        }
        itens.add(new ItemCarrinho(produto, quantidade));
    }

    public void removerItem(int produtoId, int quantidade) {
        itens.removeIf(item -> {
            if (item.getProduto().getId() == produtoId) {
                item.setQuantidade(item.getQuantidade() - quantidade);
                return item.getQuantidade() <= 0;
            }
            return false;
        });
    }

    public double getTotal() {
        return itens.stream()
                .mapToDouble(item -> item.getProduto().getPreco() * item.getQuantidade())
                .sum();
    }

    public List<ItemCarrinho> getItens() {
        return new ArrayList<>(itens);
    }

    public boolean isEmpty() {
        return itens.isEmpty();
    }
}