package com.ufrn.loja.Model;

import java.util.Objects;

public class Lojista extends Usuario {

    private String cnpj;
    private String nomeLoja;
    private String telefone;

    // Construtor padrão
    public Lojista() {
        super();
        this.setTipo("lojista");
    }

    // Construtor com atributos básicos
    public Lojista(String nome, String email, String senha) {
        super(nome, email, senha, "lojista");
    }

    // Construtor com todos os atributos
    public Lojista(int id, String nome, String email, String senha, String nomeLoja, String cnpj, String telefone) {
        super(id, nome, email, senha, "lojista");
        this.nomeLoja = nomeLoja;
        this.cnpj = cnpj;
        this.telefone = telefone;
    }

    // Getters e Setters
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeLoja() {
        return nomeLoja;
    }

    public void setNomeLoja(String nomeLoja) {
        this.nomeLoja = nomeLoja;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    // Validação simples de dados
    public boolean dadosValidos() {
        return getNome() != null && !getNome().trim().isEmpty()
                && getEmail() != null && getEmail().contains("@")
                && getSenha() != null && getSenha().length() >= 6
                && nomeLoja != null && !nomeLoja.trim().isEmpty()
                && cnpj != null && cnpj.matches("\\d{14}");
    }

    // Método para verificar se é lojista (pode ser útil em controle de acesso)
    @Override
    public boolean isLojista() {
        return "lojista".equalsIgnoreCase(getTipo());
    }

    // Representação textual
    @Override
    public String toString() {
        return "Lojista{" +
                "id=" + getId() +
                ", nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", nomeLoja='" + nomeLoja + '\'' +
                ", cnpj='" + cnpj + '\'' +
                ", telefone='" + telefone + '\'' +
                '}';
    }

    // equals e hashCode baseados no ID
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Lojista)) return false;
        Lojista lojista = (Lojista) o;
        return getId() == lojista.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
