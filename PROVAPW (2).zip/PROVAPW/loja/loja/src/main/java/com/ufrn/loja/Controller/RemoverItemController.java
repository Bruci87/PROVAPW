package com.ufrn.loja.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.ufrn.lojaonline.model.Carrinho;

@WebServlet("/carrinho/remover")
public class RemoverItemController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("carrinho") == null) {
            resp.sendRedirect("/produtos");
            return;
        }

        try {
            int produtoId = Integer.parseInt(req.getParameter("id"));
            int quantidade = Integer.parseInt(req.getParameter("quantidade"));

            Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");
            carrinho.removerItem(produtoId, quantidade);

            resp.sendRedirect("/carrinho");
        } catch (NumberFormatException | NullPointerException e) {
            resp.sendRedirect("/carrinho?erro=1");
        }
    }
}
