package br.ufrn.lojaonline.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.ufrn.lojaonline.dao.ProdutoDAO;
import br.ufrn.lojaonline.model.Produto;

@WebServlet("/lojista/produtos")
public class CadastroProdutoController extends HttpServlet {

    private final ProdutoDAO produtoDao;

    public CadastroProdutoController() throws SQLException {
        this.produtoDao = new ProdutoDAO();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Verifica se é lojista
        HttpSession session = req.getSession(false);
        if(session == null || !"lojista".equals(session.getAttribute("tipo"))) {
            resp.sendRedirect("/login");
            return;
        }

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Cadastro de Produtos</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; margin: 20px; }");
        out.println("form { max-width: 300px; margin: 0 auto; }");
        out.println("table { width: 100%; border-collapse: collapse; }");
        out.println("th, td { border: 1px solid #ddd; padding: 8px; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Cadastrar Novo Produto</h2>");
        out.println("<form method='post'>");
        out.println("<input type='text' name='nome' placeholder='Nome' required><br>");
        out.println("<input type='number' step='0.01' name='preco' placeholder='Preço' required><br>");
        out.println("<input type='number' name='estoque' placeholder='Estoque' required><br>");
        out.println("<button type='submit'>Cadastrar</button>");
        out.println("</form>");

        try {
            out.println("<h2>Produtos Cadastrados</h2>");
            out.println("<table>");
            out.println("<tr><th>Nome</th><th>Preço</th><th>Estoque</th></tr>");

            for(Produto p : produtoDao.listarTodos()) {
                out.println("<tr>");
                out.println("<td>" + p.getNome() + "</td>");
                out.println("<td>R$ " + String.format("%.2f", p.getPreco()) + "</td>");
                out.println("<td>" + p.getEstoque() + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
        } catch(SQLException e) {
            out.println("<p>Erro ao carregar produtos</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Verifica se é lojista
        HttpSession session = req.getSession(false);
        if(session == null || !"lojista".equals(session.getAttribute("tipo"))) {
            resp.sendRedirect("/login");
            return;
        }

        try {
            String nome = req.getParameter("nome");
            double preco = Double.parseDouble(req.getParameter("preco"));
            int estoque = Integer.parseInt(req.getParameter("estoque"));


            Produto novo = new Produto();produtoDao.cadastrar(novo);

            resp.sendRedirect("/lojista/produtos");
        } catch (NumberFormatException | SQLException e) {
            resp.sendRedirect("/lojista/produtos?erro=1");
        }
    }
}
