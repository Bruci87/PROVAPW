package com.ufrn.loja.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.ufrn.lojaonline.dao.ClienteDAO;
import br.ufrn.lojaonline.dao.LojistaDAO;
import br.ufrn.lojaonline.model.Cliente;

@WebServlet("/login")
public class LoginController extends HttpServlet {

    private ClienteDAO clienteDao;
    private LojistaDAO lojistaDao;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            this.clienteDao = new ClienteDAO();
            this.lojistaDao = new LojistaDAO();
        } catch (SQLException e) {
            throw new ServletException("Erro ao inicializar DAOs", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Login</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 20px; }");
        out.println("form { max-width: 300px; margin: 0 auto; }");
        out.println("input { margin-bottom: 10px; width: 100%; padding: 8px; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Login</h2>");
        out.println("<form method='post'>");
        out.println("<input type='email' name='email' placeholder='Email' required><br>");
        out.println("<input type='password' name='senha' placeholder='Senha' required><br>");
        out.println("<button type='submit'>Entrar</button>");
        out.println("</form>");
        out.println("<p>Ainda não tem conta? <a href='/cadastro'>Cadastre-se</a></p>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");

        try {
            // Tenta autenticar como cliente
            Cliente cliente = clienteDao.buscarPorEmail(email);
            if (cliente != null && cliente.getSenha().equals(senha)) {
                HttpSession session = req.getSession();
                session.setAttribute("usuario", cliente);
                session.setAttribute("tipo", "cliente");
                resp.sendRedirect("/produtos");
                return;
            }

            // Tenta autenticar como lojista
            if (lojistaDao.validarCredenciais(email, senha)) {
                HttpSession session = req.getSession();
                session.setAttribute("usuario", lojistaDao.buscarPorEmail(email));
                session.setAttribute("tipo", "lojista");
                resp.sendRedirect("/produtos/gerenciar");
                return;
            }

            // Credenciais inválidas
            resp.sendRedirect("/login?erro=Credenciais inválidas");
        } catch (SQLException e) {
            resp.sendRedirect("/login?erro=Erro no servidor");
        }
    }

    @Override
    public void destroy() {
        if (clienteDao != null) {
            clienteDao.close();  // Fechar a conexão com o banco de dados, se necessário
        }
        if (lojistaDao != null) {
            lojistaDao.close();  // Fechar a conexão com o banco de dados, se necessário
        }
    }
}
