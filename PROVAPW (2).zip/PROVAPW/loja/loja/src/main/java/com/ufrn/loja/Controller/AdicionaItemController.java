package com.ufrn.loja.Controller;

import com.ufrn.loja.Dao.ProdutoDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

package com.ufrn.loja.Dao.ProdutoDAO;//Preciso ainda criar as dao
package com.ufrn.loja.Model.Carrinho;
package com.ufrn.loja.Model.Produto;

public class AdicionaItemController extends com.ufrn.loja.Controller.HttpServlet {

    private final ProdutoDAO produtoDao;

    public AdicionaItemController() {
        try {
            this.produtoDao = new ProdutoDAO();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize ProdutoDAO", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Carrinho carrinho = (Carrinho) session.getAttribute("carrinho");

        if(carrinho == null) {
            carrinho = new Carrinho();
            session.setAttribute("carrinho", carrinho);
        }

        try {
            int produtoId = Integer.parseInt(req.getParameter("id"));
            Produto produto = produtoDao.buscarPorId(produtoId);

            if(produto != null) {
                int quantidade = 1; // Default quantity
                carrinho.adicionarItem(produto, quantidade);
            }

            resp.sendRedirect("/produtos");
        } catch (NumberFormatException | IOException e) {
            // Log the exception
            Logger.getLogger(AdicionaItemController.class.getName()).log(Level.SEVERE, "Error processing request", e);
        }
    }
}
